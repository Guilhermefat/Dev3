from abc import ABC, abstractmethod

class Transporte(ABC):
        @abstractmethod
        def entregar(self, pacote):
            pass

class Caminhao(Transporte):
      def entregar(self, pacote):
            return f"Caminhao entregando pacote {pacote}"

class Navio(Transporte):
      def entregar(self, pacote):
            return f"Navio entregando pacote {pacote}"

class FabricaTransporte:
      def criar_transporte(self, tipo_transporte):
        if tipo_transporte == "Caminhao":
              return Caminhao()
        elif tipo_transporte == 'Navio':
              return Navio()
        else:
              ValueError("Transporte inválido")

fabrica_transporte = FabricaTransporte()
caminhao = fabrica_transporte.criar_transporte("Caminhao")
navio = fabrica_transporte.criar_transporte("Navio")
print(caminhao.entregar("PTZ145"))
print(navio.entregar("ZKC554"))
